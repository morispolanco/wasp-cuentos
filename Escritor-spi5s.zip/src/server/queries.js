import HttpError from '@wasp/core/HttpError.js'

export const getStory = async ({ storyId }, context) => {
  if (!context.user) { throw new HttpError(401); }

  const story = await context.entities.Story.findUnique({
    where: { id: storyId, userId: context.user.id },
    include: { user: true }
  });

  if (!story) { throw new HttpError(404, 'Story not found or does not belong to user.'); }

  return story;
}

export const getUserStories = async ({ userId }, context) => {
  if (!context.user) { throw new HttpError(401) }

  const stories = await context.entities.Story.findMany({
    where: {
      userId
    }
  });

  return stories;
}