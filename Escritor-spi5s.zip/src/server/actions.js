import HttpError from '@wasp/core/HttpError.js'

export const createStory = async (args, context) => {
  if (!context.user) { throw new HttpError(401) };

  const newStory = await context.entities.Story.create({
    data: {
      title: args.title,
      content: args.content,
      user: { connect: { id: context.user.id } }
    }
  });

  return newStory;
}

export const updateStory = async (args, context) => {
  if (!context.user) { throw new HttpError(401) };

  const story = await context.entities.Story.findUnique({
    where: { id: args.storyId, userId: context.user.id }
  });
  if (!story) { throw new HttpError(404) };

  return context.entities.Story.update({
    where: { id: args.storyId },
    data: { title: args.title, content: args.content }
  });
}