import React from 'react';
import { Link } from 'react-router-dom';
import { useQuery } from '@wasp/queries';
import useAuth from '@wasp/auth/useAuth';
import getUserStories from '@wasp/queries/getUserStories';

export function Dashboard() {
  const { user } = useAuth();
  const { data: stories, isLoading, error } = useQuery(getUserStories, { userId: user.id });

  if (isLoading) return 'Loading...';
  if (error) return 'Error: ' + error;

  return (
    <div className='p-4'>
      {stories.map((story) => (
        <div
          key={story.id}
          className='flex items-center justify-between bg-gray-100 p-4 mb-4 rounded-lg'
        >
          <div>{story.title}</div>
          <div>
            <Link
              to={`/story/${story.id}`}
              className='bg-green-500 hover:bg-green-700 text-white font-bold py-2 px-4 rounded'
            >
              Read More
            </Link>
          </div>
        </div>
      ))}
    </div>
  );
}