import React, { useState } from 'react';
import { useAction } from '@wasp/actions';
import createStory from '@wasp/actions/createStory';

export function CreateStory() {
  const [title, setTitle] = useState('');
  const [content, setContent] = useState('');
  const createStoryFn = useAction(createStory);

  const handleCreateStory = () => {
    createStoryFn({ title, content });
    setTitle('');
    setContent('');
  };

  return (
    <div className='p-4'>
      <input
        type='text'
        placeholder='Title'
        className='px-1 py-2 border rounded text-lg'
        value={title}
        onChange={(e) => setTitle(e.target.value)}
      />
      <textarea
        placeholder='Content'
        className='px-1 py-2 mt-4 border rounded text-lg'
        rows='6'
        value={content}
        onChange={(e) => setContent(e.target.value)}
      ></textarea>
      <button
        onClick={handleCreateStory}
        className='bg-green-500 hover:bg-green-700 text-white font-bold py-2 px-4 rounded mt-4'
      >
        Create Story
      </button>
    </div>
  );
}