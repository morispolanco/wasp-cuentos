import React, { useState } from 'react';
import { useParams, Link } from 'react-router-dom';
import { useQuery } from '@wasp/queries';
import { useAction } from '@wasp/actions';
import getStory from '@wasp/queries/getStory';
import updateStory from '@wasp/actions/updateStory';

export function Story() {
  const { storyId } = useParams();
  const { data: story, isLoading, error } = useQuery(getStory, { storyId });
  const updateStoryFn = useAction(updateStory);
  const [title, setTitle] = useState(story?.title || '');
  const [content, setContent] = useState(story?.content || '');

  if (isLoading) return 'Loading...';
  if (error) return 'Error: ' + error;

  const handleUpdateStory = () => {
    updateStoryFn({ storyId, title, content });
  };

  return (
    <div className='p-4'>
      <div className='flex items-center justify-between mb-4'>
        <input
          type='text'
          placeholder='Title'
          className='border rounded py-2 px-4'
          value={title}
          onChange={(e) => setTitle(e.target.value)}
        />
        <button
          onClick={handleUpdateStory}
          className='bg-blue-500 hover:bg-blue-700 text-white font-bold py-2 px-4 rounded'
        >
          Update
        </button>
      </div>
      <textarea
        className='border rounded py-2 px-4 w-full'
        rows='10'
        value={content}
        onChange={(e) => setContent(e.target.value)}
      ></textarea>
      <Link to={`/`} className='bg-red-500 hover:bg-red-700 text-white font-bold py-2 px-4 rounded mt-4'>Go Back</Link>
    </div>
  );
}